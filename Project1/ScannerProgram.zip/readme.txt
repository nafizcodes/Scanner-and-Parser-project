Necessary Precondition: 
---------------------------------------------------------------------------------------------------------------------
1. Download the Python Executable Installer from, "https://www.python.org/downloads/".
2. Run the installer. Make sure to select both the checkboxes at the bottom and then click Install Now.
3. To ensure if Python is succesfully installed on your system. Follow the given steps −

	- Open the command prompt.

	- Type ‘python --version’ and press enter.

	- If Python was successfully installed on your OS, the version of Python which you installed will be displayed. 
----------------------------------------------------------------------------------------------------------------------

Steps for Testing ScannerProgram
---------------------------------
1. Place the ScannerProgram folder from the ZIP File onto your Desktop.
2. We have included 6 text files named (testfile1.txt - testfile6.txt) for testing purposes. (If you would like to test your own text file, please place it within the ScannerProgram folder at this point)
3. Open the Command Prompt on your Windows PC.
4. Inside of the Command Prompt Terminal type, "cd Desktop" (PRESS ENTER), "cd ScannerProgram" (PRESS ENTER). This will place your directory location in the ScannerProgram folder where your source code and textfiles exist.
5. Now, inside of the Command Prompt Terminal, type, "python Scanner.py {TEXT FILE NAME}.txt" (i.e Scanner.txt). => "python Scanner.py Scanner.txt" (PRESS ENTER).

